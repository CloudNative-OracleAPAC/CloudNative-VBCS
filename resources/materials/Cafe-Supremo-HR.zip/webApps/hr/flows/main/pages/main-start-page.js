define([], function() {
  'use strict';

  var PageModule = function PageModule() {



    Bots.init({
      appId: '5c36e787fd3ced0022c78a98'
      // appId: '5bc6fedee333590022ea8c31'
    }).then(function(res) {
      Bots.updateUser({
        "givenName": "John",
        "surname": "Smith",
        "email": "John.Smith@example.com",
        "userId": "vbcs.demo"
      });
    });

  };

  return PageModule;
});