define([
    'vbsw/helpers/serviceWorkerHelpers',
    /**
     * Add the following entries to include the toolkit classes that you'll use. More information about these
     * classes can be found in the toolkit's API doc. See the link to the API doc in the paragraph before 
     * this sample file.
     * 
     */
    'persist/persistenceManager',
    'persist/defaultResponseProxy',
    'persist/fetchStrategies',
    /**
     * Add the following entry to enable console logging while you develop your app with the toolkit.
     */
    'persist/impl/logger',
    'opt/simpleJsonShredding',
    'opt/persistenceStoreManager',
    'opt/pouchDBPersistenceStoreFactory',
    './resources/lib/customCache.js',
    'opt/queryHandlers'
  ],
  function(ServiceWorkerHelpers, PersistenceManager, DefaultResponseProxy,
    FetchStrategies, Logger, simpleJsonShredding, persistenceStoreManager,
    pouchDBPersistenceStoreFactory, cacheStrategy, queryHandlers) {
    'use strict';

    function AppModule() {
      persistenceStoreManager.registerDefaultStoreFactory(
        pouchDBPersistenceStoreFactory);
    }

    function OfflineHandler() {
      var self = this;
      /**
       * Enable console logging of the toolkit for development testing
       */
      Logger.option('level', Logger.LEVEL_LOG);
      Logger.option('writer', console);

      function _handlePatch(request) {
        if (PersistenceManager.isOnline()) {
          return PersistenceManager.browserFetch(request);
        } else {
          return new Promise(function(resolve, reject) {
            console.log(request)
            var header = new Headers();
            header.append('Content-Type', 'application/json');
            var response = new Response('{}', {
              status: 200,
              headers: header
            });
            console.log("Patch method called")
            resolve(response)
          });
        }
      }

      function _handlePost(request) {
        if (PersistenceManager.isOnline()) {
          return PersistenceManager.browserFetch(request);
        } else {
          return new Promise(function(resolve, reject) {
            console.log(request)
            var header = new Headers();
            header.append('Content-Type', 'application/json');
            var response = new Response(
              '{"message": "Object stored locally."}', {
                status: 200,
                headers: header
              });
            console.log("Post method called")
            resolve(response)
          });
        }
      };

      function _handleGet(request) {
        if (PersistenceManager.isOnline()) {
          return PersistenceManager.browserFetch(request);
        } else {
          return new Promise(function(resolve, reject) {
            console.log(request)
            var header = new Headers();
            header.append('Content-Type', 'application/json');
            var response = new Response(
              '{"name": "Object stored locally."}', {
                status: 200,
                headers: header
              });
            console.log("Get method called")
            resolve(response)
          });
        }
      }
      var options = {
        /**
         * The following code snippets implements the toolkit's CacheFirstStrategy. This strategy 
         * checks the application's cache for the requested data before it makes a request to cache 
         * data. The code snippet also disables the background fetch of data.
         */
        //         jsonProcessor: {
        //           shredder: simpleJsonShredding.getShredder('Purchase',
        //             'id'),
        //           unshredder: simpleJsonShredding.getUnshredder()
        //         },
        //         queryHandler: queryHandlers.getSimpleQueryHandler('Purchase'),
        fetchStrategy: FetchStrategies.getCacheIfOfflineStrategy(),
        cacheStrategy: cacheStrategy.getHttpCacheHeaderStrategy(),
        requestHandlerOverride: {
          handlePost: _handlePost,
          handlePatch: _handlePatch
          // handleGet: _handleGet
        }
      };

      self._responseProxy = DefaultResponseProxy.getResponseProxy(options);

      self.afterRequestListener = function(event) {
        console.log(event)
        event.request.text().then(function(data) {
          console.log(data)
        })
        var statusCode = event.response.status;
        //         if (statusCode == 201) {
        return new Promise(function(resolve, reject) {
          resolve(event.response)
        })
        //         }
      }
      PersistenceManager.getSyncManager().addEventListener('syncRequest',
        self.afterRequestListener, '/');
    }

    OfflineHandler.prototype.handleRequest = function(request, scope) {
      var self = this;
      /**
       * (Optional). Write output from the OfflineHandler to your browser's console. Useful to help 
       * you understand  the code that follows.
       */
      console.log('OfflineHandler.handleRequest() url = ' + request.url +
        ' cache = ' + request.cache +
        ' mode = ' + request.mode);

      /**
       * Cache requests where the URL matches the scope for which you want data cached.
       */
      return self._responseProxy.processRequest(request);
    };

    OfflineHandler.prototype.beforeSyncRequestListener = function(event) {
      console.log('here beforeSyncRequestListener ')
      console.log(event)
      return Promise.resolve();
    };
    OfflineHandler.prototype.afterSyncRequestListener = function(event) {
      console.log('here afterSyncRequestListener')
      console.log(event)
      return Promise.resolve();
    };
    AppModule.prototype.createOfflineHandler = function() {
      /** Create the OfflineHandler that makes the toolkit cache data URLs */
      return Promise.resolve(new OfflineHandler());
    };
    AppModule.prototype.isOnline = function() {
      return ServiceWorkerHelpers.isOnline();
    };
    AppModule.prototype.forceOffline = function(flag) {
      return ServiceWorkerHelpers.forceOffline(flag).then(function() {
        /** if online, perform a data sync */
        if (!flag) {
          return ServiceWorkerHelpers.syncOfflineData();
        }
        return Promise.resolve();

      }).catch(function(error) {
        console.error(error);
      });
    };

    AppModule.prototype.syncOfflineData = function() {
      return new Promise(function(resolve, reject) {

        ServiceWorkerHelpers.syncOfflineData().then(function(data) {
          console.log(data)
          if (!data) {
            resolve();
          }
        }, function(error) {
          console.log(error);
          //           PersistenceManager.getSyncManager().removeRequest(error.requestId);
          resolve();
        })

        //         PersistenceManager.getSyncManager().sync().then(function(data) {
        //           if (!data) {
        //             resolve();
        //           }
        //         }, function(error) {
        //           console.log(error);
        //           PersistenceManager.getSyncManager().removeRequest(error.requestId);
        //           resolve();
        //         })

      })


    }
    AppModule.prototype.fetchFromSyncLog = function(method) {
      return new Promise(function(resolve, reject) {

        persistenceStoreManager.openStore('syncLog').then(function(
          store) {
          store.find({
            selector: {
              "metadata.method": {
                $eq: method
              }
            },
            fields: ['_id']
          }).then(function(data) {
            resolve(data);
          }).catch(function(err) {
            reject();
          })
        });
      })
    }


    AppModule.prototype.fetchFromOfflineCaches = function() {
      return new Promise(function(resolve, reject) {
        persistenceStoreManager.openStore('offlineCaches-systemCache').then(
          function(
            store) {
            store.find({
              selector: {
                "value.name": {
                  $eq: 'sumedh'
                }
              }
            }).then(function(data) {
              console.log(data)
            })
          });
      })
    }

    AppModule.prototype.deleteFromSyncLog = function(requestId) {
      PersistenceManager.getSyncManager().removeRequest(requestId);
    };

    AppModule.prototype.findByKeyFromSyncLog = function(key) {
      return new Promise(function(resolve, reject) {
        persistenceStoreManager.openStore('syncLog').then(function(
          store) {
          store.find({
            selector: {
              "_id": {
                $eq: key
              }
            },
            fields: ['_id']
          }).then(function(data) {
            resolve(data);
          }).catch(function(err) {
            reject();
          })
        });
      })
    };

    AppModule.prototype.getObjectById = function(objectPath, id) {
      return new Promise(function(resolve, reject) {
        persistenceStoreManager.openStore('offlineCaches-systemCache').then(
          function(
            store) {
            store.find({
              selector: {
                "metadata.url": {
                  $eq: 'https://abcs-gse00009991.builder.us.oraclecloud.com/design/Cafe_Supremo_HR/1.0.3/resources/data/' + objectPath
                },
                "metadata.method": {
                  $eq: 'GET'
                }
              }
            }).then(function(data) {
              console.log(data)
            })
          });
      })
    }


    AppModule.prototype.isFormValid = function(form) {
      var tracker = document.getElementById(form);

      if (tracker.valid === "valid") {
        return true;
      } else {
        tracker.showMessages();
        tracker.focusOn("@firstInvalidShown");
        return false;
      }
    };

    return AppModule;
  });