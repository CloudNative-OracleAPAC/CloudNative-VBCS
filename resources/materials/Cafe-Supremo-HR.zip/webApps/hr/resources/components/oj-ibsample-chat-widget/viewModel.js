/******************************************************************************
 Copyright (c) 2016-2018, Oracle and/or its affiliates. All rights reserved.

 $revision_history$
 06-mar-2018   Steven Davelaar, Oracle A-Team
 2.0           Upgraded to JET 4.x, implemented Oracle CCA standards
 12-oct-2017   Steven Davelaar, Oracle A-Team
 1.2           Upgraded to IB 1.1 Conversation Model
 15-aug-2017   Steven Davelaar, Oracle A-Team
 1.2           Cleaned up the code
 12-jan-2017   Steven Davelaar, Oracle A-Team
 1.1           Modified for use with Intelligent Bots
 27-oct-2016   Steven Davelaar & Lydumil Pelov, Oracle A-Team
 1.0           initial creation
 ******************************************************************************/
define(['ojs/ojcore', 'knockout', 'jquery', './lib/reconnecting-websocket', 'require', 'ojs/ojinputtext', 'ojs/ojknockout'
        , 'promise', 'ojs/ojlistview', 'ojs/ojarraytabledatasource'
        , 'ojs/ojfilmstrip', 'ojs/ojdialog'],
    function (oj, ko, $, ReconnectingWebSocket, require) {
        function model(context) {
            var self = this;
            var messageToBot;
            var currentConnection;
            self.uniqueId = context.uniqueId;
            self.topId = "top_id_"+context.uniqueId;
            self.notSupportedDialog = "not_supported_dialog_"+context.uniqueId;
            self.waitingForText = ko.observable(false);
            self.waitingForTextImageUrl = require.toUrl("./images/waitingForText.gif");
            
            var LOCATION_TYPE = 'location';
            var POSTBACK_TYPE = 'postback';
            var ws;
            context.props.then(function (properties) {
                self.properties = properties;
                initMessageToBot(self.properties.channel);
                ReconnectingWebSocket.debugAll = false;
                initWebSocketIfNeeded();
            });

            // close websocket connection when we leave page with tester CCA
            self.dispose = function (context) {
                if (ws) {
                    ws.close();
                }
            };

            var initWebSocketIfNeeded = function () {
                var connection = self.properties.websocketConnectionUrl + "?user=" + self.properties.userId;
                if (connection !== currentConnection) {
                    currentConnection = connection;
                    ws = new ReconnectingWebSocket(connection);
                    ws.onmessage = function (evt) {
                        self.waitingForText(false);
                        debug("Message received: " + evt.data);
                        var response = JSON.parse(evt.data);
                        if (response.hasOwnProperty('body') && response.body.hasOwnProperty('messagePayload')) {
                            // process IB V1.1 message
                            // we no longer support V1.0 messages, the webhook platform version
                            // should be set to 1.1
                            var messagePayload = response.body.messagePayload;
                            debug("Message payload: " + JSON.stringify(messagePayload));
                            self.addItem(messagePayload,true);
                        }
                        else if (response.hasOwnProperty('error')) {
                            self.addItem({"type":"text","text":response.error.message}, true);
                        }
                    };

                    ws.onclose = function () {
                        debug("Connection is closed...");
                    };

                    ws.onerror = function (error) {
                        self.waitingForText(false);
                        self.onerror(error);
                    };
                }

            };

            self.value = ko.observable("");
            self.itemToAdd = ko.observable("");
            self.scrollPos = ko.observable(5000);

            self.reset = function () {
                // re-init websocket when userId or connection url has changed
                initWebSocketIfNeeded();
                self.allItems([]);
                // re-init messageToBot to pick up changes to channel id
                initMessageToBot(self.properties.channel);
            };

            var initMessageToBot = function(channel) {
                messageToBot = {
                    "to": {
                        "type": "bot",
                        "id": channel
                    }
                };
            };

            self.getDisplayUrl = function (url) {
                var pos = url.indexOf("://");
                var startpos = pos === -1 ? 0 : pos + 3;
                var endpos = url.indexOf('/', startpos);
                endpos = endpos === -1 ? url.length : endpos;
                return url.substring(startpos, endpos);
            };

            // send message to the bot
            var sendToBot = function (message, isAcknowledge) {
                // wait for websocket until open
                waitForSocketConnection(ws, function () {
                    self.waitingForText(true);
                    ws.send(JSON.stringify(message));
                    debug('Message sent: ' + JSON.stringify(message));
                });
            };

            var waitForSocketConnection = function (socket, callback) {
                setTimeout(
                    function () {
                        if (socket.readyState === 1) {
                            callback();
                            return;

                        } else {
                            debug("waiting for connection...");
                            waitForSocketConnection(socket, callback);
                        }

                    }, 1000); // wait 1 second for the connection...
            };
            var debug = function (msg) {
                console.log(msg);
            };

            self.onerror = function (error) {
                console.error('WebSocket Error;', error);
            };

            ko.extenders.scrollFollow = function (target, selector) {
                target.subscribe(function (newval) {
                setTimeout(function () {
                    var elem = document.getElementById(self.topId);
                    elem.scrollTop = elem.scrollHeight;
                    }, 100);     
                });

                return target;
            };

            self.allItems = ko.observableArray([]).extend({scrollFollow: '#list-view'+self.uniqueId});
            var lastItemId = self.allItems().length;
            if (lastItemId > 1)
                scrollBottom();

            //self.dataSource = new oj.ArrayTableDataSource(self.allItems, {idAttribute: "id"})

            self.addItem = function (value, isBot) {
                // TODO: don't add if value is empty!
                lastItemId++;
                self.allItems.push(
                    {
                        id: lastItemId,
                        payload: value,
                        bot: isBot
                    }
                );
            };

            // this will be when typing!
            self.valueChangeHandler = function (event) {
                // Free text is entered
                var value = event.detail.value;
                if (value!=='') {
                    messageToBot.messagePayload= {type:"text",text:value};
                    self.addItem(value, false);
                    self.value("");
                    sendToBot(messageToBot);    
                }
            };

            self.notSupportedMessage = ko.observable();

            // predefined selection!
            self.onClientSelection = function (action) {
                self.addItem(action.label, false);
                if (action.type === POSTBACK_TYPE) {
                    messageToBot.messagePayload = {"type":"postback","postback":action.postback};
                    sendToBot(messageToBot);
                } else if (action.type === LOCATION_TYPE) {
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function (position) {
                            messageToBot.messagePayload = {"type": 'location', location: {"latitude": position.coords.latitude, "longitude": position.coords.longitude}};
                            sendToBot(messageToBot);
                        });
                    } else {
                        self.notSupportedMessage('Geo location is not supported by this browser');
                        $("#"+self.notSupportedDialog).ojDialog("open");
                    }
                } else {
                    self.notSupportedMessage('Action type ' + action.type + ' is not supported');
                    $("#"+self.notSupportedDialog).ojDialog("open");
                }
            };

            self.closeNotSupportedDialog = function () {
                $("#"+self.notSupportedDialog).ojDialog("close");
            };

            // film trip properties!
            // self.currentNavArrowPlacement = ko.observable("adjacent");
            // self.currentNavArrowVisibility = ko.observable("auto");
            self.currentNavArrowPlacement = ko.observable("overlay");
            self.currentNavArrowVisibility = ko.observable("hidden");

        }
        return model;
    }
);