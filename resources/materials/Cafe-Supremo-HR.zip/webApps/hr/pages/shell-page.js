define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.setAppLanguage = function(selectedLocale) {
    if (selectedLocale) {
      window.localStorage.setItem('myApp.locale', selectedLocale);
    }
  }
  return PageModule;
});